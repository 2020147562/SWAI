// Configuration
const API_URL = 'YOUR_APPS_SCRIPT_WEB_APP_URL';

// Language settings
let nativeLanguage = 'ko';
let targetLanguage = 'en';

// Predefined word lists for each language
const LANGUAGE_WORDS = {
    'en': {
        nouns: [
            'book', 'computer', 'phone', 'house', 'car', 'tree', 'water', 'food', 'time', 'day',
            'year', 'person', 'world', 'life', 'hand', 'part', 'child', 'eye', 'woman', 'place',
            'work', 'week', 'case', 'problem', 'fact', 'government', 'number', 'group', 'company',
            'question', 'business', 'study', 'room', 'market', 'reason', 'point', 'account',
            'program', 'issue', 'side', 'kind', 'head', 'house', 'service', 'friend', 'father',
            'power', 'hour', 'game', 'line', 'end', 'member', 'law', 'car', 'city', 'community'
        ],
        verbs: [
            'make', 'know', 'get', 'see', 'come', 'think', 'look', 'want', 'give', 'use',
            'find', 'tell', 'ask', 'work', 'seem', 'feel', 'try', 'leave', 'call', 'need',
            'become', 'include', 'continue', 'set', 'learn', 'change', 'lead', 'understand',
            'watch', 'follow', 'stop', 'create', 'speak', 'read', 'allow', 'add', 'spend',
            'grow', 'open', 'walk', 'win', 'offer', 'remember', 'love', 'consider', 'appear',
            'buy', 'wait', 'serve', 'die', 'send', 'expect', 'build', 'stay', 'fall', 'cut'
        ]
    },
    'ko': {
        nouns: [
            '책', '컴퓨터', '전화', '집', '자동차', '나무', '물', '음식', '시간', '날',
            '해', '사람', '세계', '인생', '손', '부분', '아이', '눈', '여자', '장소',
            '일', '주', '케이스', '문제', '사실', '정부', '숫자', '그룹', '회사',
            '질문', '사업', '공부', '방', '시장', '이유', '점', '계정', '프로그램', '이슈',
            '쪽', '종류', '머리', '집', '서비스', '친구', '아버지', '힘', '시간', '게임',
            '선', '끝', '멤버', '법', '자동차', '도시', '지역사회'
        ],
        verbs: [
            '만들다', '알다', '얻다', '보다', '오다', '생각하다', '보다', '원하다', '주다', '사용하다',
            '찾다', '말하다', '묻다', '일하다', '보이다', '느끼다', '시도하다', '떠나다', '부르다', '필요하다',
            '되다', '포함하다', '계속하다', '설정하다', '배우다', '변하다', '이끌다', '이해하다',
            '보다', '따르다', '멈추다', '만들다', '말하다', '읽다', '허용하다', '더하다', '쓰다',
            '자라다', '열다', '걷다', '이기다', '제안하다', '기억하다', '사랑하다', '고려하다', '나타나다',
            '사다', '기다리다', '서비스하다', '죽다', '보내다', '기대하다', '짓다', '머무르다', '떨어지다', '자르다'
        ]
    },
    'ja': {
        nouns: [
            '本', 'コンピュータ', '電話', '家', '車', '木', '水', '食べ物', '時間', '日',
            '年', '人', '世界', '人生', '手', '部分', '子供', '目', '女性', '場所',
            '仕事', '週', 'ケース', '問題', '事実', '政府', '数字', 'グループ', '会社',
            '質問', 'ビジネス', '勉強', '部屋', '市場', '理由', '点', 'アカウント', 'プログラム', '問題',
            '側', '種類', '頭', '家', 'サービス', '友達', '父', '力', '時間', 'ゲーム',
            '線', '終わり', 'メンバー', '法律', '車', '都市', 'コミュニティ'
        ],
        verbs: [
            '作る', '知る', '得る', '見る', '来る', '考える', '見る', '欲しい', '与える', '使う',
            '見つける', '言う', '聞く', '働く', '見える', '感じる', '試す', '去る', '呼ぶ', '必要',
            'なる', '含む', '続ける', '設定する', '学ぶ', '変わる', '導く', '理解する',
            '見る', '従う', '止める', '作る', '話す', '読む', '許可する', '加える', '使う',
            '育つ', '開く', '歩く', '勝つ', '提供する', '覚える', '愛する', '考慮する', '現れる',
            '買う', '待つ', 'サービスする', '死ぬ', '送る', '期待する', '建てる', '留まる', '落ちる', '切る'
        ]
    },
    'zh': {
        nouns: [
            '书', '电脑', '电话', '房子', '汽车', '树', '水', '食物', '时间', '天',
            '年', '人', '世界', '生活', '手', '部分', '孩子', '眼睛', '女人', '地方',
            '工作', '周', '案例', '问题', '事实', '政府', '数字', '团体', '公司',
            '问题', '商业', '学习', '房间', '市场', '原因', '点', '账户', '程序', '问题',
            '边', '种类', '头', '房子', '服务', '朋友', '父亲', '力量', '时间', '游戏',
            '线', '结束', '成员', '法律', '汽车', '城市', '社区'
        ],
        verbs: [
            '做', '知道', '得到', '看', '来', '想', '看', '想要', '给', '使用',
            '找到', '说', '问', '工作', '看起来', '感觉', '尝试', '离开', '叫', '需要',
            '成为', '包括', '继续', '设置', '学习', '改变', '领导', '理解',
            '看', '跟随', '停止', '创造', '说话', '读', '允许', '添加', '花费',
            '成长', '打开', '走', '赢', '提供', '记住', '爱', '考虑', '出现',
            '买', '等待', '服务', '死', '发送', '期望', '建造', '停留', '落下', '切'
        ]
    },
    'es': {
        nouns: [
            'libro', 'computadora', 'teléfono', 'casa', 'coche', 'árbol', 'agua', 'comida', 'tiempo', 'día',
            'año', 'persona', 'mundo', 'vida', 'mano', 'parte', 'niño', 'ojo', 'mujer', 'lugar',
            'trabajo', 'semana', 'caso', 'problema', 'hecho', 'gobierno', 'número', 'grupo', 'empresa',
            'pregunta', 'negocio', 'estudio', 'habitación', 'mercado', 'razón', 'punto', 'cuenta', 'programa', 'problema',
            'lado', 'tipo', 'cabeza', 'casa', 'servicio', 'amigo', 'padre', 'poder', 'hora', 'juego',
            'línea', 'fin', 'miembro', 'ley', 'coche', 'ciudad', 'comunidad'
        ],
        verbs: [
            'hacer', 'saber', 'obtener', 'ver', 'venir', 'pensar', 'mirar', 'querer', 'dar', 'usar',
            'encontrar', 'decir', 'preguntar', 'trabajar', 'parecer', 'sentir', 'intentar', 'dejar', 'llamar', 'necesitar',
            'convertirse', 'incluir', 'continuar', 'establecer', 'aprender', 'cambiar', 'liderar', 'entender',
            'ver', 'seguir', 'detener', 'crear', 'hablar', 'leer', 'permitir', 'añadir', 'gastar',
            'crecer', 'abrir', 'caminar', 'ganar', 'ofrecer', 'recordar', 'amar', 'considerar', 'aparecer',
            'comprar', 'esperar', 'servir', 'morir', 'enviar', 'esperar', 'construir', 'quedarse', 'caer', 'cortar'
        ]
    },
    'fr': {
        nouns: [
            'livre', 'ordinateur', 'téléphone', 'maison', 'voiture', 'arbre', 'eau', 'nourriture', 'temps', 'jour',
            'année', 'personne', 'monde', 'vie', 'main', 'partie', 'enfant', 'œil', 'femme', 'lieu',
            'travail', 'semaine', 'cas', 'problème', 'fait', 'gouvernement', 'nombre', 'groupe', 'entreprise',
            'question', 'entreprise', 'étude', 'chambre', 'marché', 'raison', 'point', 'compte', 'programme', 'problème',
            'côté', 'type', 'tête', 'maison', 'service', 'ami', 'père', 'pouvoir', 'heure', 'jeu',
            'ligne', 'fin', 'membre', 'loi', 'voiture', 'ville', 'communauté'
        ],
        verbs: [
            'faire', 'savoir', 'obtenir', 'voir', 'venir', 'penser', 'regarder', 'vouloir', 'donner', 'utiliser',
            'trouver', 'dire', 'demander', 'travailler', 'sembler', 'sentir', 'essayer', 'quitter', 'appeler', 'avoir besoin',
            'devenir', 'inclure', 'continuer', 'établir', 'apprendre', 'changer', 'conduire', 'comprendre',
            'regarder', 'suivre', 'arrêter', 'créer', 'parler', 'lire', 'permettre', 'ajouter', 'dépenser',
            'grandir', 'ouvrir', 'marcher', 'gagner', 'offrir', 'se souvenir', 'aimer', 'considérer', 'apparaître',
            'acheter', 'attendre', 'servir', 'mourir', 'envoyer', 'attendre', 'construire', 'rester', 'tomber', 'couper'
        ]
    },
    'de': {
        nouns: [
            'Buch', 'Computer', 'Telefon', 'Haus', 'Auto', 'Baum', 'Wasser', 'Essen', 'Zeit', 'Tag',
            'Jahr', 'Person', 'Welt', 'Leben', 'Hand', 'Teil', 'Kind', 'Auge', 'Frau', 'Ort',
            'Arbeit', 'Woche', 'Fall', 'Problem', 'Tatsache', 'Regierung', 'Zahl', 'Gruppe', 'Unternehmen',
            'Frage', 'Geschäft', 'Studium', 'Zimmer', 'Markt', 'Grund', 'Punkt', 'Konto', 'Programm', 'Problem',
            'Seite', 'Art', 'Kopf', 'Haus', 'Dienst', 'Freund', 'Vater', 'Macht', 'Stunde', 'Spiel',
            'Linie', 'Ende', 'Mitglied', 'Gesetz', 'Auto', 'Stadt', 'Gemeinschaft'
        ],
        verbs: [
            'machen', 'wissen', 'bekommen', 'sehen', 'kommen', 'denken', 'schauen', 'wollen', 'geben', 'benutzen',
            'finden', 'sagen', 'fragen', 'arbeiten', 'scheinen', 'fühlen', 'versuchen', 'verlassen', 'rufen', 'brauchen',
            'werden', 'einschließen', 'fortsetzen', 'festlegen', 'lernen', 'ändern', 'führen', 'verstehen',
            'beobachten', 'folgen', 'stoppen', 'erstellen', 'sprechen', 'lesen', 'erlauben', 'hinzufügen', 'ausgeben',
            'wachsen', 'öffnen', 'gehen', 'gewinnen', 'anbieten', 'erinnern', 'lieben', 'betrachten', 'erscheinen',
            'kaufen', 'warten', 'dienen', 'sterben', 'senden', 'erwarten', 'bauen', 'bleiben', 'fallen', 'schneiden'
        ]
    }
};

// DOM Elements
const wordQuiz = document.getElementById('wordQuiz');
const currentWord = document.getElementById('currentWord');
const options = document.getElementById('options');
const wordList = document.getElementById('wordList');
const startLearningBtn = document.getElementById('startLearning');
const nativeLanguageSelect = document.getElementById('nativeLanguage');
const targetLanguageSelect = document.getElementById('targetLanguage');

// Cache for translations
let translationCache = new Map();

// Function to detect language
async function detectLanguage(text) {
    try {
        const response = await fetch('https://ws.detectlanguage.com/0.2/detect', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Authorization': 'Bearer f1bc6b5299937a37f75dce49c6905a9a'
            },
            body: `q=${encodeURIComponent(text)}`
        });
        const data = await response.json();
        if (data.data && data.data.detections && data.data.detections.length > 0) {
            const detection = data.data.detections[0];
            const languageMap = {
                'en': 'en',
                'ko': 'ko',
                'ja': 'ja',
                'zh': 'zh',
                'es': 'es',
                'fr': 'fr',
                'de': 'de'
            };
            return languageMap[detection.language] || detection.language;
        }
        return null;
    } catch (error) {
        // fallback: heuristic
        return detectLanguageHeuristic(text);
    }
}

// Fallback function using simple heuristics for language detection
function detectLanguageHeuristic(text) {
    // Korean character range
    const koreanRegex = /[\uAC00-\uD7AF\u1100-\u11FF\u3130-\u318F\uA960-\uA97F\uD7B0-\uD7FF]/;
    // Japanese character ranges
    const japaneseRegex = /[\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FFF]/;
    // Chinese character range
    const chineseRegex = /[\u4E00-\u9FFF]/;
    
    if (koreanRegex.test(text)) {
        return 'ko';
    } else if (japaneseRegex.test(text)) {
        return 'ja';
    } else if (chineseRegex.test(text)) {
        return 'zh';
    }
    
    // If no specific characters are found, assume it's English
    // This is a very basic heuristic and might not be accurate
    return 'en';
}
// Function to save language settings
async function saveLanguageSettings() {
    const settings = {
        nativeLanguage: nativeLanguageSelect.value,
        targetLanguage: targetLanguageSelect.value
    };
    
    await chrome.storage.local.set({ languageSettings: settings });
    console.log('Language settings saved:', settings);
    
    // Update global variables
    nativeLanguage = settings.nativeLanguage;
    targetLanguage = settings.targetLanguage;
    
    // Notify content script about language change
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        if (tabs[0]) {
            chrome.tabs.sendMessage(tabs[0].id, {
                type: 'languageSettingsChanged',
                settings: settings
            });
        }
    });
}

// Function to load language settings
async function loadLanguageSettings() {
    const data = await chrome.storage.local.get(['languageSettings']);
    const settings = data.languageSettings || { nativeLanguage: 'ko', targetLanguage: 'en' };
    
    // Update select elements
    nativeLanguageSelect.value = settings.nativeLanguage;
    targetLanguageSelect.value = settings.targetLanguage;
    
    // Update global variables
    nativeLanguage = settings.nativeLanguage;
    targetLanguage = settings.targetLanguage;
    
    console.log('Language settings loaded:', settings);
}

// Function to get translation (updated to use language settings)
async function getTranslation(word) {
    if (translationCache.has(word)) {
        return translationCache.get(word);
    }

    try {
        const response = await fetch(
            `https://api.mymemory.translated.net/get?q=${encodeURIComponent(word)}&langpair=${targetLanguage}|${nativeLanguage}`
        );
        const data = await response.json();
        if (data.responseData && data.responseData.translatedText) {
            const translation = data.responseData.translatedText;
            translationCache.set(word, translation);
            return translation;
        }
    } catch (error) {
        console.error('Translation error:', error);
    }
    return null;
}

// Function to get random fake answers
async function getRandomFakeAnswers(count, correctWord, correctLanguage) {
    // Get word list for the correct language
    const wordList = LANGUAGE_WORDS[correctLanguage];
    if (!wordList) {
        console.error('No word list available for language:', correctLanguage);
        return [];
    }

    // Combine nouns and verbs
    const allWords = [...wordList.nouns, ...wordList.verbs];
    
    // Filter out the correct word and get random words
    const shuffledWords = allWords
        .filter(word => word !== correctWord)
        .sort(() => Math.random() - 0.5)
        .slice(0, count);

    return shuffledWords;
}

// Load vocabulary
function loadVocabulary() {
    console.log('Loading vocabulary...');
    chrome.storage.local.get(['vocabulary'], function(result) {
        console.log('Loaded vocabulary:', result.vocabulary);
        const vocabulary = result.vocabulary || [];
        
        wordList.innerHTML = '';
        if (vocabulary.length === 0) {
            wordList.innerHTML = '<div style="text-align: center; color: #666;">No words saved yet</div>';
            return;
        }
        
        vocabulary.forEach(word => {
            const wordItem = document.createElement('div');
            wordItem.className = 'word-item';
            wordItem.style.display = 'flex';
            wordItem.style.justifyContent = 'space-between';
            wordItem.style.alignItems = 'center';
            wordItem.style.padding = '10px';
            wordItem.style.borderBottom = '1px solid #eee';
            
            wordItem.innerHTML = `
                <div style="flex-grow: 1;">
                    <div style="font-weight: bold;">${word.word}</div>
                    <div style="color: #666;">${word.translation}</div>
                    <div style="font-size: 12px; color: #999; font-style: italic;">${word.example}</div>
                </div>
                <button class="delete-word" data-word="${word.word}" 
                    style="background-color: #ff4444; color: white; border: none; 
                    padding: 5px 10px; border-radius: 3px; cursor: pointer; margin-left: 10px;">
                    Delete
                </button>
            `;
            
            wordList.appendChild(wordItem);
        });
        
        // Add delete event listeners
        document.querySelectorAll('.delete-word').forEach(button => {
            button.addEventListener('click', async (e) => {
                const wordToDelete = e.target.dataset.word;
                console.log('Deleting word:', wordToDelete);
                try {
                    chrome.storage.local.get(['vocabulary'], function(result) {
                        const vocabulary = result.vocabulary || [];
                        const updatedVocabulary = vocabulary.filter(w => w.word !== wordToDelete);
                        chrome.storage.local.set({ vocabulary: updatedVocabulary }, function() {
                            console.log('Word deleted:', wordToDelete);
                            loadVocabulary(); // Reload the list
                        });
                    });
                } catch (error) {
                    console.error('Error deleting word:', error);
                }
            });
        });
    });
}

// Start word quiz
async function startQuiz() {
    console.log('Starting quiz...');
    chrome.storage.local.get(['vocabulary'], async function(result) {
        const vocabulary = result.vocabulary || [];
        console.log('Quiz vocabulary:', vocabulary);
        
        if (vocabulary.length === 0) {
            currentWord.textContent = 'No words in vocabulary';
            options.innerHTML = '';
            return;
        }
        
        const randomWord = vocabulary[Math.floor(Math.random() * vocabulary.length)];
        currentWord.textContent = randomWord.word;
        
        // Detect language of the correct answer
        const correctLanguage = await detectLanguage(randomWord.translation);
        console.log('Detected language of correct answer:', correctLanguage);
        
        // Generate options
        const correctOption = randomWord.translation;
        const fakeAnswers = await getRandomFakeAnswers(3, correctOption, correctLanguage);
        
        const allOptions = [...fakeAnswers, correctOption]
            .sort(() => Math.random() - 0.5);
        
        options.innerHTML = '';
        allOptions.forEach(option => {
            const optionElement = document.createElement('div');
            optionElement.className = 'option';
            optionElement.style.padding = '10px';
            optionElement.style.margin = '5px 0';
            optionElement.style.border = '1px solid #ddd';
            optionElement.style.borderRadius = '4px';
            optionElement.style.cursor = 'pointer';
            optionElement.textContent = option;
            
            optionElement.addEventListener('click', () => {
                if (option === correctOption) {
                    optionElement.style.backgroundColor = '#4CAF50';
                    optionElement.style.color = 'white';
                    
                    // Remove word from vocabulary after correct answer
                    chrome.storage.local.get(['vocabulary'], function(result) {
                        const vocabulary = result.vocabulary || [];
                        const updatedVocabulary = vocabulary.filter(w => w.word !== randomWord.word);
                        chrome.storage.local.set({ vocabulary: updatedVocabulary }, function() {
                            console.log('Word removed after correct answer:', randomWord.word);
                            setTimeout(() => {
                                loadVocabulary(); // Reload the vocabulary list
                                startQuiz(); // Start next question
                            }, 1000);
                        });
                    });
                } else {
                    optionElement.style.backgroundColor = '#f44336';
                    optionElement.style.color = 'white';
                    setTimeout(startQuiz, 1000);
                }
            });
            
            options.appendChild(optionElement);
        });
    });
}

// Initialize popup
document.addEventListener('DOMContentLoaded', async function() {
    console.log('Popup script loaded');
    
    // Load language settings
    await loadLanguageSettings();
    
    // Add event listeners for language selection
    nativeLanguageSelect.addEventListener('change', saveLanguageSettings);
    targetLanguageSelect.addEventListener('change', saveLanguageSettings);
    
    // Initial load of vocabulary
    loadVocabulary();
    
    // Add click event listener for Start Learning button
    if (startLearningBtn) {
        console.log('Start Learning button found');
        startLearningBtn.addEventListener('click', () => {
            console.log('Start Learning clicked');
            if (wordQuiz) {
                wordQuiz.style.display = 'block';
                startQuiz();
                // 퀴즈 영역이 팝업의 맨 아래까지 보이도록 스크롤
                setTimeout(() => {
                    window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
                }, 100);
            } else {
                console.error('Word quiz element not found');
            }
        });
    } else {
        console.error('Start Learning button not found');
    }
}); 