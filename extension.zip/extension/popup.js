// Configuration
const API_URL = 'YOUR_APPS_SCRIPT_WEB_APP_URL';

// Common English words for fake answers
const COMMON_WORDS = [
    // Nouns
    'book', 'computer', 'phone', 'house', 'car', 'tree', 'water', 'food', 'time', 'day',
    'year', 'person', 'world', 'life', 'hand', 'part', 'child', 'eye', 'woman', 'place',
    'work', 'week', 'case', 'problem', 'fact', 'government', 'number', 'group', 'company',
    'question', 'business', 'study', 'room', 'market', 'reason', 'point', 'account',
    'program', 'issue', 'side', 'kind', 'head', 'house', 'service', 'friend', 'father',
    'power', 'hour', 'game', 'line', 'end', 'member', 'law', 'car', 'city', 'community',
    // Verbs
    'make', 'know', 'get', 'see', 'come', 'think', 'look', 'want', 'give', 'use',
    'find', 'tell', 'ask', 'work', 'seem', 'feel', 'try', 'leave', 'call', 'need',
    'become', 'include', 'continue', 'set', 'learn', 'change', 'lead', 'understand',
    'watch', 'follow', 'stop', 'create', 'speak', 'read', 'allow', 'add', 'spend',
    'grow', 'open', 'walk', 'win', 'offer', 'remember', 'love', 'consider', 'appear',
    'buy', 'wait', 'serve', 'die', 'send', 'expect', 'build', 'stay', 'fall', 'cut'
];

// DOM Elements
const wordQuiz = document.getElementById('wordQuiz');
const currentWord = document.getElementById('currentWord');
const options = document.getElementById('options');
const wordList = document.getElementById('wordList');
const startLearningBtn = document.getElementById('startLearning');

// Cache for translations
let translationCache = new Map();

// Function to get translation
async function getTranslation(word) {
    if (translationCache.has(word)) {
        return translationCache.get(word);
    }

    try {
        const response = await fetch(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(word)}&langpair=en|ko`);
        const data = await response.json();
        if (data.responseData && data.responseData.translatedText) {
            const translation = data.responseData.translatedText;
            translationCache.set(word, translation);
            return translation;
        }
    } catch (error) {
        console.error('Translation error:', error);
    }
    return null;
}

// Function to get random fake answers
async function getRandomFakeAnswers(count, excludeWord) {
    const shuffledWords = COMMON_WORDS
        .filter(word => word !== excludeWord)
        .sort(() => Math.random() - 0.5)
        .slice(0, count);

    const fakeAnswers = [];
    for (const word of shuffledWords) {
        const translation = await getTranslation(word);
        if (translation) {
            fakeAnswers.push(translation);
        }
    }
    return fakeAnswers;
}

// Load vocabulary
function loadVocabulary() {
    console.log('Loading vocabulary...');
    chrome.storage.local.get(['vocabulary'], function(result) {
        console.log('Loaded vocabulary:', result.vocabulary);
        const vocabulary = result.vocabulary || [];
        
        wordList.innerHTML = '';
        if (vocabulary.length === 0) {
            wordList.innerHTML = '<div style="text-align: center; color: #666;">No words saved yet</div>';
            return;
        }
        
        vocabulary.forEach(word => {
            const wordItem = document.createElement('div');
            wordItem.className = 'word-item';
            wordItem.style.display = 'flex';
            wordItem.style.justifyContent = 'space-between';
            wordItem.style.alignItems = 'center';
            wordItem.style.padding = '10px';
            wordItem.style.borderBottom = '1px solid #eee';
            
            wordItem.innerHTML = `
                <div style="flex-grow: 1;">
                    <div style="font-weight: bold;">${word.word}</div>
                    <div style="color: #666;">${word.translation}</div>
                    <div style="font-size: 12px; color: #999; font-style: italic;">${word.example}</div>
                </div>
                <button class="delete-word" data-word="${word.word}" 
                    style="background-color: #ff4444; color: white; border: none; 
                    padding: 5px 10px; border-radius: 3px; cursor: pointer; margin-left: 10px;">
                    Delete
                </button>
            `;
            
            wordList.appendChild(wordItem);
        });
        
        // Add delete event listeners
        document.querySelectorAll('.delete-word').forEach(button => {
            button.addEventListener('click', async (e) => {
                const wordToDelete = e.target.dataset.word;
                console.log('Deleting word:', wordToDelete);
                try {
                    chrome.storage.local.get(['vocabulary'], function(result) {
                        const vocabulary = result.vocabulary || [];
                        const updatedVocabulary = vocabulary.filter(w => w.word !== wordToDelete);
                        chrome.storage.local.set({ vocabulary: updatedVocabulary }, function() {
                            console.log('Word deleted:', wordToDelete);
                            loadVocabulary(); // Reload the list
                        });
                    });
                } catch (error) {
                    console.error('Error deleting word:', error);
                }
            });
        });
    });
}

// Start word quiz
async function startQuiz() {
    console.log('Starting quiz...');
    chrome.storage.local.get(['vocabulary'], async function(result) {
        const vocabulary = result.vocabulary || [];
        console.log('Quiz vocabulary:', vocabulary);
        
        if (vocabulary.length === 0) {
            currentWord.textContent = 'No words in vocabulary';
            options.innerHTML = '';
            return;
        }
        
        const randomWord = vocabulary[Math.floor(Math.random() * vocabulary.length)];
        currentWord.textContent = randomWord.word;
        
        // Generate options
        const correctOption = randomWord.translation;
        const fakeAnswers = await getRandomFakeAnswers(3, randomWord.word);
        
        const allOptions = [...fakeAnswers, correctOption]
            .sort(() => Math.random() - 0.5);
        
        options.innerHTML = '';
        allOptions.forEach(option => {
            const optionElement = document.createElement('div');
            optionElement.className = 'option';
            optionElement.style.padding = '10px';
            optionElement.style.margin = '5px 0';
            optionElement.style.border = '1px solid #ddd';
            optionElement.style.borderRadius = '4px';
            optionElement.style.cursor = 'pointer';
            optionElement.textContent = option;
            
            optionElement.addEventListener('click', () => {
                if (option === correctOption) {
                    optionElement.style.backgroundColor = '#4CAF50';
                    optionElement.style.color = 'white';
                    
                    // Remove word from vocabulary after correct answer
                    chrome.storage.local.get(['vocabulary'], function(result) {
                        const vocabulary = result.vocabulary || [];
                        const updatedVocabulary = vocabulary.filter(w => w.word !== randomWord.word);
                        chrome.storage.local.set({ vocabulary: updatedVocabulary }, function() {
                            console.log('Word removed after correct answer:', randomWord.word);
                            setTimeout(() => {
                                loadVocabulary(); // Reload the vocabulary list
                                startQuiz(); // Start next question
                            }, 1000);
                        });
                    });
                } else {
                    optionElement.style.backgroundColor = '#f44336';
                    optionElement.style.color = 'white';
                    setTimeout(startQuiz, 1000);
                }
            });
            
            options.appendChild(optionElement);
        });
    });
}

// Initialize popup
document.addEventListener('DOMContentLoaded', function() {
    console.log('Popup script loaded');
    
    // Initial load of vocabulary
    loadVocabulary();
    
    // Add click event listener for Start Learning button
    if (startLearningBtn) {
        console.log('Start Learning button found');
        startLearningBtn.addEventListener('click', () => {
            console.log('Start Learning clicked');
            if (wordQuiz) {
                wordQuiz.style.display = 'block';
                startQuiz();
            } else {
                console.error('Word quiz element not found');
            }
        });
    } else {
        console.error('Start Learning button not found');
    }
}); 