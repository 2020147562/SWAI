// Configuration
const API_URL = 'YOUR_APPS_SCRIPT_WEB_APP_URL';

// Predefined word lists
const TOEIC_WORDS = [
  'accomplish', 'achieve', 'adequate', 'adjust', 'advantage',
  'advocate', 'affect', 'agenda', 'agreement', 'allocate'
];

const SAT_WORDS = [
  'abate', 'abdicate', 'aberration', 'abhor', 'abide',
  'abject', 'abjure', 'abnegation', 'abort', 'abridge'
];

// Track selected words and their selection count
let selectedWords = new Map();
let currentTooltip = null;

// Function to save word to vocabulary
async function saveWord(word, translation, example) {
    console.log('Saving word:', word);
    try {
        // Get current vocabulary
        const data = await new Promise((resolve) => {
            chrome.storage.local.get(['vocabulary'], resolve);
        });
        
        const vocabulary = data.vocabulary || [];
        
        // Check if word already exists
        if (!vocabulary.some(item => item.word === word)) {
            vocabulary.push({
                word: word,
                translation: translation,
                example: example,
                timestamp: new Date().toISOString()
            });
            
            await new Promise((resolve) => {
                chrome.storage.local.set({ vocabulary: vocabulary }, resolve);
            });
            console.log('Word saved successfully');
        } else {
            console.log('Word already exists in vocabulary');
        }
    } catch (error) {
        console.error('Error saving word:', error);
    }
}

// Function to update tooltip position
function updateTooltipPosition(tooltip, selection) {
    if (!tooltip || !selection.rangeCount) return;
    
    const range = selection.getRangeAt(0);
    const rect = range.getBoundingClientRect();
    const viewport = {
        width: window.innerWidth,
        height: window.innerHeight
    };
    
    // Calculate position (bottom-left of selection)
    let left = rect.left;
    let top = rect.bottom;
    
    // Add 10px gap
    top += 10;
    
    // Ensure tooltip stays within viewport
    if (left + tooltip.offsetWidth > viewport.width - 10) {
        left = viewport.width - tooltip.offsetWidth - 10;
    }
    
    // If tooltip would go below viewport, show it above the selection
    if (top + tooltip.offsetHeight > viewport.height - 10) {
        top = rect.top - tooltip.offsetHeight - 10;
        tooltip.style.transformOrigin = 'bottom left';
    } else {
        tooltip.style.transformOrigin = 'top left';
    }
    
    tooltip.style.left = `${left}px`;
    tooltip.style.top = `${top}px`;
}

// Function to show translation tooltip
function showTranslation(word) {
    console.log('Showing translation for:', word);
    
    // Remove existing tooltip if any
    if (currentTooltip) {
        currentTooltip.remove();
        currentTooltip = null;
    }
    
    // Create new tooltip
    const tooltip = document.createElement('div');
    tooltip.id = 'translation-tooltip';
    tooltip.style.cssText = `
        position: fixed;
        background: white;
        border: none;
        padding: 15px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        z-index: 10000;
        max-width: 300px;
        min-width: 200px;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
        transform-origin: top left;
        animation: tooltipAppear 0.2s ease-out;
    `;
    
    // Get selection coordinates
    const selection = window.getSelection();
    if (!selection.rangeCount) return;
    
    // Add loading message with spinner
    tooltip.innerHTML = `
        <div class="tooltip-loading">
            <div class="loading-spinner"></div>
            <div class="loading-text">Translating...</div>
        </div>
    `;
    document.body.appendChild(tooltip);
    currentTooltip = tooltip;
    
    // Initial position
    updateTooltipPosition(tooltip, selection);
    
    // Add scroll event listener
    const scrollHandler = () => {
        if (currentTooltip) {
            updateTooltipPosition(currentTooltip, selection);
        }
    };
    
    window.addEventListener('scroll', scrollHandler);
    
    // Get translation and example
    Promise.all([
        fetch(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(word)}&langpair=en|ko`)
            .then(response => response.json()),
        fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(word)}`)
            .then(response => {
                if (!response.ok) {
                    console.log(`Dictionary API not available for word: ${word}`);
                    return null;
                }
                return response.json();
            })
            .catch(() => {
                console.log(`Dictionary API error for word: ${word}`);
                return null;
            })
    ])
    .then(([translationData, exampleData]) => {
        console.log('Translation response:', translationData);
        if (translationData.responseData && translationData.responseData.translatedText) {
            const translatedText = translationData.responseData.translatedText;
            const example = exampleData?.[0]?.meanings?.[0]?.definitions?.[0]?.example || '';
            
            // Create tooltip content
            tooltip.innerHTML = `
                <div class="tooltip-content">
                    <div class="tooltip-word">${word}</div>
                    <div class="tooltip-translation">${translatedText}</div>
                    ${example ? `
                        <div class="tooltip-divider"></div>
                        <div class="tooltip-example">${example}</div>
                    ` : ''}
                </div>
            `;
            
            // Update position after content is loaded
            updateTooltipPosition(tooltip, selection);
            
            // Save word automatically
            saveWord(word, translatedText, example);
        } else {
            tooltip.innerHTML = `
                <div class="tooltip-content">
                    <div class="tooltip-error">Translation not available</div>
                </div>
            `;
        }
    })
    .catch(error => {
        console.error('Translation error:', error);
        tooltip.innerHTML = `
            <div class="tooltip-content">
                <div class="tooltip-error">Error loading translation</div>
            </div>
        `;
    });
    
    // Remove tooltip when clicking outside
    const handleClickOutside = (e) => {
        if (!tooltip.contains(e.target)) {
            tooltip.classList.add('tooltip-fade-out');
            setTimeout(() => {
                tooltip.remove();
                currentTooltip = null;
                window.removeEventListener('scroll', scrollHandler);
            }, 200);
            document.removeEventListener('click', handleClickOutside);
        }
    };
    
    // Add click listener with a small delay to prevent immediate removal
    setTimeout(() => {
        document.addEventListener('click', handleClickOutside);
    }, 100);
}

// Add CSS for tooltip animations and styling
const style = document.createElement('style');
style.textContent = `
    @keyframes tooltipAppear {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    @keyframes spin {
        to { transform: rotate(360deg); }
    }
    
    .tooltip-fade-out {
        animation: tooltipFadeOut 0.2s ease-out forwards;
    }
    
    @keyframes tooltipFadeOut {
        to {
            opacity: 0;
            transform: translateY(-10px);
        }
    }
    
    .tooltip-loading {
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 10px;
    }
    
    .loading-spinner {
        width: 20px;
        height: 20px;
        border: 2px solid #f3f3f3;
        border-top: 2px solid #3498db;
        border-radius: 50%;
        animation: spin 1s linear infinite;
        margin-bottom: 8px;
    }
    
    .loading-text {
        color: #666;
        font-size: 14px;
    }
    
    .tooltip-content {
        padding: 5px;
    }
    
    .tooltip-word {
        font-size: 16px;
        font-weight: 600;
        color: #2c3e50;
        margin-bottom: 8px;
    }
    
    .tooltip-translation {
        font-size: 15px;
        color: #34495e;
        margin-bottom: 8px;
    }
    
    .tooltip-divider {
        height: 1px;
        background: #e0e0e0;
        margin: 8px 0;
    }
    
    .tooltip-example {
        font-size: 13px;
        color: #7f8c8d;
        font-style: italic;
        line-height: 1.4;
    }
    
    .tooltip-error {
        color: #e74c3c;
        font-size: 14px;
        text-align: center;
    }
`;
document.head.appendChild(style);

// Initialize the extension
console.log('Content script starting...');

// Add word selection handler
document.addEventListener('mouseup', function(e) {
    const selectedText = window.getSelection().toString().trim();
    console.log('Selected text:', selectedText);
    
    if (selectedText && selectedText.length > 0) {
        // Show translation tooltip (which will also save the word)
        showTranslation(selectedText);
    }
}); 