// Configuration
const API_URL = 'YOUR_APPS_SCRIPT_WEB_APP_URL';

// Language settings
let nativeLanguage = 'ko';
let targetLanguage = 'en';

// Load language settings
async function loadLanguageSettings() {
    const data = await chrome.storage.local.get(['languageSettings']);
    const settings = data.languageSettings || { nativeLanguage: 'ko', targetLanguage: 'en' };
    nativeLanguage = settings.nativeLanguage;
    targetLanguage = settings.targetLanguage;
    console.log('Content script: Language settings loaded:', settings);
}

// Listen for language settings changes
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'languageSettingsChanged') {
        nativeLanguage = message.settings.nativeLanguage;
        targetLanguage = message.settings.targetLanguage;
        console.log('Content script: Language settings updated:', message.settings);
    }
});

// Initialize language settings
loadLanguageSettings();

// Predefined word lists
const TOEIC_WORDS = [
  'accomplish', 'achieve', 'adequate', 'adjust', 'advantage',
  'advocate', 'affect', 'agenda', 'agreement', 'allocate'
];

const SAT_WORDS = [
  'abate', 'abdicate', 'aberration', 'abhor', 'abide',
  'abject', 'abjure', 'abnegation', 'abort', 'abridge'
];

// Track selected words and their selection count
let selectedWords = new Map();
let currentTooltip = null;

// Function to save word to vocabulary
async function saveWord(word, translation, example) {
    console.log('Saving word:', word);
    try {
        // Get current vocabulary
        const data = await new Promise((resolve) => {
            chrome.storage.local.get(['vocabulary'], resolve);
        });
        
        const vocabulary = data.vocabulary || [];
        
        // Check if word already exists
        if (!vocabulary.some(item => item.word === word)) {
            vocabulary.push({
                word: word,
                translation: translation,
                example: example,
                timestamp: new Date().toISOString()
            });
            
            await new Promise((resolve) => {
                chrome.storage.local.set({ vocabulary: vocabulary }, resolve);
            });
            console.log('Word saved successfully');
        } else {
            console.log('Word already exists in vocabulary');
        }
    } catch (error) {
        console.error('Error saving word:', error);
    }
}

// Function to update tooltip position
function updateTooltipPosition(tooltip, selection) {
    if (!tooltip || !selection.rangeCount) return;
    
    const range = selection.getRangeAt(0);
    const rect = range.getBoundingClientRect();
    const viewport = {
        width: window.innerWidth,
        height: window.innerHeight
    };
    
    // Calculate position (bottom-left of selection)
    let left = rect.left;
    let top = rect.bottom;
    
    // Add 10px gap
    top += 10;
    
    // Ensure tooltip stays within viewport
    if (left + tooltip.offsetWidth > viewport.width - 10) {
        left = viewport.width - tooltip.offsetWidth - 10;
    }
    
    // If tooltip would go below viewport, show it above the selection
    if (top + tooltip.offsetHeight > viewport.height - 10) {
        top = rect.top - tooltip.offsetHeight - 10;
        tooltip.style.transformOrigin = 'bottom left';
    } else {
        tooltip.style.transformOrigin = 'top left';
    }
    
    tooltip.style.left = `${left}px`;
    tooltip.style.top = `${top}px`;
}

// Function to detect language
async function detectLanguage(text) {
    try {
        const response = await fetch('https://ws.detectlanguage.com/0.2/detect', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Authorization': 'Bearer f1bc6b5299937a37f75dce49c6905a9a'
            },
            body: `q=${encodeURIComponent(text)}`
        });
        const data = await response.json();
        if (data.data && data.data.detections && data.data.detections.length > 0) {
            const detection = data.data.detections[0];
            const languageMap = {
                'en': 'en',
                'ko': 'ko',
                'ja': 'ja',
                'zh': 'zh',
                'es': 'es',
                'fr': 'fr',
                'de': 'de'
            };
            return languageMap[detection.language] || detection.language;
        }
        return null;
    } catch (error) {
        // fallback: heuristic
        return detectLanguageHeuristic(text);
    }
}

// Fallback function using simple heuristics for language detection
function detectLanguageHeuristic(text) {
    // Korean character range
    const koreanRegex = /[\uAC00-\uD7AF\u1100-\u11FF\u3130-\u318F\uA960-\uA97F\uD7B0-\uD7FF]/;
    // Japanese character ranges
    const japaneseRegex = /[\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FFF]/;
    // Chinese character range
    const chineseRegex = /[\u4E00-\u9FFF]/;
    
    if (koreanRegex.test(text)) {
        return 'ko';
    } else if (japaneseRegex.test(text)) {
        return 'ja';
    } else if (chineseRegex.test(text)) {
        return 'zh';
    }
    
    // If no specific characters are found, assume it's English
    // This is a very basic heuristic and might not be accurate
    return 'en';
}

// Function to show translation tooltip (updated with language detection)
async function showTranslation(word) {
    console.log('Showing translation for:', word);
    
    // Remove existing tooltip if any
    if (currentTooltip) {
        currentTooltip.remove();
        currentTooltip = null;
    }
    
    // Create new tooltip
    const tooltip = document.createElement('div');
    tooltip.id = 'translation-tooltip';
    tooltip.style.cssText = `
        position: fixed;
        background: white;
        border: none;
        padding: 15px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        z-index: 10000;
        max-width: 300px;
        min-width: 200px;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
        transform-origin: top left;
        animation: tooltipAppear 0.2s ease-out;
    `;
    
    // Add loading message with spinner
    tooltip.innerHTML = `
        <div class="tooltip-loading">
            <div class="loading-spinner"></div>
            <div class="loading-text">Detecting language...</div>
        </div>
    `;
    document.body.appendChild(tooltip);
    currentTooltip = tooltip;
    
    // Initial position
    const selection = window.getSelection();
    if (!selection.rangeCount) return;
    updateTooltipPosition(tooltip, selection);
    
    // Add scroll event listener
    const scrollHandler = () => {
        if (currentTooltip) {
            updateTooltipPosition(currentTooltip, selection);
        }
    };
    window.addEventListener('scroll', scrollHandler);
    
    try {
        // Detect language first
        const detectedLang = await detectLanguage(word);
        console.log('Detected language:', detectedLang);
        
        // Update loading message
        tooltip.innerHTML = `
            <div class="tooltip-loading">
                <div class="loading-spinner"></div>
                <div class="loading-text">Translating...</div>
            </div>
        `;
        
        // Determine translation direction based on detected language
        let sourceLang, targetLang;
        if (detectedLang === nativeLanguage) {
            // If detected language is native language, translate to target language
            sourceLang = nativeLanguage;
            targetLang = targetLanguage;
        } else {
            // If detected language is not native language, translate to native language
            sourceLang = detectedLang || targetLanguage; // fallback to target language if detection fails
            targetLang = nativeLanguage;
        }
        
        console.log('Translation direction:', `${sourceLang} -> ${targetLang}`);
        
        // Get translation and example
        const [translationData, exampleData] = await Promise.all([
            fetch(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(word)}&langpair=${sourceLang}|${targetLang}`)
                .then(response => response.json()),
            fetch(`https://api.dictionaryapi.dev/api/v2/entries/${sourceLang}/${encodeURIComponent(word)}`)
                .then(response => {
                    if (!response.ok) {
                        console.log(`Dictionary API not available for word: ${word}`);
                        return null;
                    }
                    return response.json();
                })
                .catch(() => {
                    console.log(`Dictionary API error for word: ${word}`);
                    return null;
                })
        ]);
        
        console.log('Translation response:', translationData);
        if (translationData.responseData && translationData.responseData.translatedText) {
            const translatedText = translationData.responseData.translatedText;
            const example = exampleData?.[0]?.meanings?.[0]?.definitions?.[0]?.example || '';
            
            // Create tooltip content with language information
            tooltip.innerHTML = `
                <div class="tooltip-content">
                    <div class="tooltip-word">${word}</div>
                    <div class="tooltip-lang-info" style="font-size: 12px; color: #666; margin-bottom: 5px;">
                        ${detectedLang ? `Detected: ${detectedLang.toUpperCase()}` : 'Language detection failed'}
                    </div>
                    <div class="tooltip-translation">${translatedText}</div>
                    ${example ? `
                        <div class="tooltip-divider"></div>
                        <div class="tooltip-example">${example}</div>
                    ` : ''}
                </div>
            `;
            
            // Update position after content is loaded
            updateTooltipPosition(tooltip, selection);
            
            // Save word automatically
            saveWord(word, translatedText, example);
        } else {
            tooltip.innerHTML = `
                <div class="tooltip-content">
                    <div class="tooltip-error">Translation not available</div>
                </div>
            `;
        }
    } catch (error) {
        console.error('Translation error:', error);
        tooltip.innerHTML = `
            <div class="tooltip-content">
                <div class="tooltip-error">Error loading translation</div>
            </div>
        `;
    }
    
    // Remove tooltip when clicking outside
    const handleClickOutside = (e) => {
        if (!tooltip.contains(e.target)) {
            tooltip.classList.add('tooltip-fade-out');
            setTimeout(() => {
                tooltip.remove();
                currentTooltip = null;
                window.removeEventListener('scroll', scrollHandler);
            }, 200);
            document.removeEventListener('click', handleClickOutside);
        }
    };
    
    // Add click listener with a small delay to prevent immediate removal
    setTimeout(() => {
        document.addEventListener('click', handleClickOutside);
    }, 100);
}

// Add CSS for tooltip animations and styling
const style = document.createElement('style');
style.textContent = `
    @keyframes tooltipAppear {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    @keyframes spin {
        to { transform: rotate(360deg); }
    }
    
    .tooltip-fade-out {
        animation: tooltipFadeOut 0.2s ease-out forwards;
    }
    
    @keyframes tooltipFadeOut {
        to {
            opacity: 0;
            transform: translateY(-10px);
        }
    }
    
    .tooltip-loading {
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 10px;
    }
    
    .loading-spinner {
        width: 20px;
        height: 20px;
        border: 2px solid #f3f3f3;
        border-top: 2px solid #3498db;
        border-radius: 50%;
        animation: spin 1s linear infinite;
        margin-bottom: 8px;
    }
    
    .loading-text {
        color: #666;
        font-size: 14px;
    }
    
    .tooltip-content {
        padding: 5px;
    }
    
    .tooltip-word {
        font-size: 16px;
        font-weight: 600;
        color: #2c3e50;
        margin-bottom: 8px;
    }
    
    .tooltip-translation {
        font-size: 15px;
        color: #34495e;
        margin-bottom: 8px;
    }
    
    .tooltip-divider {
        height: 1px;
        background: #e0e0e0;
        margin: 8px 0;
    }
    
    .tooltip-example {
        font-size: 13px;
        color: #7f8c8d;
        font-style: italic;
        line-height: 1.4;
    }
    
    .tooltip-error {
        color: #e74c3c;
        font-size: 14px;
        text-align: center;
    }
`;
document.head.appendChild(style);

// Initialize the extension
console.log('Content script starting...');

// Add word selection handler
document.addEventListener('mouseup', function(e) {
    const selectedText = window.getSelection().toString().trim();
    console.log('Selected text:', selectedText);
    
    if (selectedText && selectedText.length > 0) {
        // Show translation tooltip (which will also save the word)
        showTranslation(selectedText);
    }
});

// Function to get random fake answers
async function getRandomFakeAnswers(count, correctWord, correctLanguage) {
    console.log('getRandomFakeAnswers called with:', { count, correctWord, correctLanguage });
    
    // Get word list for the correct language
    const wordList = LANGUAGE_WORDS[correctLanguage];
    if (!wordList) {
        console.error('No word list available for language:', correctLanguage);
        return [];
    }
    console.log('Found word list for language:', correctLanguage);

    // Combine nouns and verbs
    const allWords = [...wordList.nouns, ...wordList.verbs];
    console.log('Total available words:', allWords.length);
    
    // Filter out the correct word and get random words
    const shuffledWords = allWords
        .filter(word => word !== correctWord)
        .sort(() => Math.random() - 0.5)
        .slice(0, count);
    
    console.log('Generated fake answers:', shuffledWords);
    return shuffledWords;
}

// Start word quiz
async function startQuiz() {
    console.log('=== Quiz Start ===');
    console.log('Starting quiz...');
    
    chrome.storage.local.get(['vocabulary'], async function(result) {
        console.log('Retrieved vocabulary from storage:', result);
        const vocabulary = result.vocabulary || [];
        console.log('Quiz vocabulary length:', vocabulary.length);
        
        if (vocabulary.length === 0) {
            console.log('No words in vocabulary, ending quiz');
            currentWord.textContent = 'No words in vocabulary';
            options.innerHTML = '';
            return;
        }
        
        const randomWord = vocabulary[Math.floor(Math.random() * vocabulary.length)];
        console.log('Selected random word:', randomWord);
        currentWord.textContent = randomWord.word;
        
        try {
            // Detect language of the correct answer
            console.log('Attempting to detect language for:', randomWord.translation);
            const correctLanguage = await detectLanguage(randomWord.translation);
            console.log('Detected language of correct answer:', correctLanguage);
            
            // Generate options
            const correctOption = randomWord.translation;
            console.log('Correct option:', correctOption);
            
            console.log('Generating fake answers...');
            const fakeAnswers = await getRandomFakeAnswers(3, correctOption, correctLanguage);
            console.log('Generated fake answers:', fakeAnswers);
            
            const allOptions = [...fakeAnswers, correctOption]
                .sort(() => Math.random() - 0.5);
            console.log('Final options array:', allOptions);
            
            options.innerHTML = '';
            allOptions.forEach(option => {
                console.log('Creating option element for:', option);
                const optionElement = document.createElement('div');
                optionElement.className = 'option';
                optionElement.style.padding = '10px';
                optionElement.style.margin = '5px 0';
                optionElement.style.border = '1px solid #ddd';
                optionElement.style.borderRadius = '4px';
                optionElement.style.cursor = 'pointer';
                optionElement.textContent = option;
                
                optionElement.addEventListener('click', () => {
                    console.log('Option clicked:', option);
                    if (option === correctOption) {
                        console.log('Correct answer selected');
                        optionElement.style.backgroundColor = '#4CAF50';
                        optionElement.style.color = 'white';
                        
                        // Remove word from vocabulary after correct answer
                        chrome.storage.local.get(['vocabulary'], function(result) {
                            const vocabulary = result.vocabulary || [];
                            const updatedVocabulary = vocabulary.filter(w => w.word !== randomWord.word);
                            chrome.storage.local.set({ vocabulary: updatedVocabulary }, function() {
                                console.log('Word removed after correct answer:', randomWord.word);
                                setTimeout(() => {
                                    loadVocabulary(); // Reload the vocabulary list
                                    startQuiz(); // Start next question
                                }, 1000);
                            });
                        });
                    } else {
                        console.log('Incorrect answer selected');
                        optionElement.style.backgroundColor = '#f44336';
                        optionElement.style.color = 'white';
                        setTimeout(startQuiz, 1000);
                    }
                });
                
                options.appendChild(optionElement);
            });
            console.log('=== Quiz Setup Complete ===');
        } catch (error) {
            console.error('Error during quiz setup:', error);
            currentWord.textContent = 'Error setting up quiz';
            options.innerHTML = '';
        }
    });
}

// Initialize popup
document.addEventListener('DOMContentLoaded', async function() {
    console.log('=== Popup Initialization ===');
    console.log('Popup script loaded');
    
    // Load language settings
    await loadLanguageSettings();
    console.log('Language settings loaded');
    
    // Add event listeners for language selection
    nativeLanguageSelect.addEventListener('change', saveLanguageSettings);
    targetLanguageSelect.addEventListener('change', saveLanguageSettings);
    console.log('Language selection listeners added');
    
    // Initial load of vocabulary
    loadVocabulary();
    console.log('Initial vocabulary loaded');
    
    // Add click event listener for Start Learning button
    if (startLearningBtn) {
        console.log('Start Learning button found');
        startLearningBtn.addEventListener('click', () => {
            console.log('Start Learning button clicked');
            if (wordQuiz) {
                console.log('Word quiz element found, displaying quiz');
                wordQuiz.style.display = 'block';
                startQuiz();
            } else {
                console.error('Word quiz element not found');
            }
        });
    } else {
        console.error('Start Learning button not found');
    }
    console.log('=== Popup Initialization Complete ===');
}); 