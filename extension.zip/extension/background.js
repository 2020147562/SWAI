// Handle installation
chrome.runtime.onInstalled.addListener(function(details) {
    if (details.reason === "install") {
        // Initialize empty vocabulary
        chrome.storage.local.set({ vocabulary: [] });
    }
});

// Handle notification click
chrome.notifications.onClicked.addListener(function() {
    // Open popup
    chrome.action.openPopup();
}); 